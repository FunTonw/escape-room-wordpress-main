# 梅添涼企業 Wordpress

> 此為六角學院「要留下，還是塊陶？」活動專用 WordPress

推薦架站軟體：[XAMPP](https://www.apachefriends.org/zh_tw/index.html)

## 主題(Theme)

主題包名稱：nogoodstheme

主題路徑：
wp-content -> themes -> nogoodstheme
